typedef CellCoordinate = ({int x, int y});
